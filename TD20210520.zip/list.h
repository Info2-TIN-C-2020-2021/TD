// list.h

#pragma once

#include <stdint.h>
#include <stdbool.h>
#include "error.h"

#define LIST_CAPACITY 10 // list size
#define END_OF_LIST (-1)

typedef double Element; // element in list

typedef struct {
  uint32_t numElem;
  Element e[LIST_CAPACITY];
} sList, *pList;



eErrorCode initList(pList l);
bool isListEmpty(sList l);
bool isListFull(sList l);
int32_t getNumElem(sList l);
void displayList(sList l);

eErrorCode insertElemAt(pList l, int32_t pos, Element e);



#if 0
eErrorCode initList(pList l);
int32_t getNumElem(pList l);
bool isListEmpty(pList l);
bool isListFull(pList l);
eErrorCode insertElemAt(pList l, int32_t pos, Element e);
Element getElemAt(pList l, int32_t pos);
#endif