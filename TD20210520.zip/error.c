// error.c

#include "error.h"

void displayError(const eErrorCode e) {
  switch(e) {
    case E_NO_ERROR:
      printf("NO ERROR\n");
      break;
    case E_BAD_LIST:
      printf("E_BAD_LIST\n");
      break;
    case E_LIST_FULL:
      printf("E_LIST_FULL\n");
      break;

    default:
      printf("UNKNOWN ERROR\n");
      break;
    }
  return;
}
