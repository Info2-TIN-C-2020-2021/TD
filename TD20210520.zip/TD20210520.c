/**
  \file      TD20210510.c
  \brief     bitmap file
  \author    Pierre BRESSY
  \version   1.0
  \date      2021-05-10 13:15:00
  \details

**/

#include <stdio.h>  // standard library for inputs and ouputs
#include <stdlib.h>
#include <stdint.h>

#include "list.h"
#include "error.h"

int main(int argc, char const *argv[])
{
  sList l;

  initList(&l);
  printf("%d element(s) in list\n", getNumElem(l));
  printf("list is empty: %s\n", isListEmpty(l) ? "YES":"NO");
  printf("list is full:  %s\n", isListFull(l) ? "YES":"NO");
  displayList(l);
  insertElemAt(&l, END_OF_LIST, 1.0);
  displayList(l);
  insertElemAt(&l, END_OF_LIST, 2.0);
  displayList(l);
  insertElemAt(&l, END_OF_LIST, 3.0);
  displayList(l);
  insertElemAt(&l, END_OF_LIST, 4.0);
  displayList(l);
  insertElemAt(&l, 2, 9.0);
  displayList(l);
  insertElemAt(&l, 1, 8.0);
  displayList(l);
  insertElemAt(&l, 0, -1.0);
  displayList(l);
  return 0;
}















