// list.c

#include "list.h"


eErrorCode initList(pList l) {
  eErrorCode returnCode = E_NO_ERROR;

  if(l!=NULL) {
    l->numElem=0;
  }
  else {
    returnCode = E_BAD_LIST;
  }
  return returnCode;
}

bool isListEmpty(sList l) {

  return l.numElem == 0;
}

bool isListFull(sList l) {

  return l.numElem == LIST_CAPACITY;
}

int32_t getNumElem(sList l){

  return l.numElem;
}


void displayList(sList l) {
  int32_t k = 0;
  for (k = 0; k < l.numElem;k++)
    printf("%6.3lf ", l.e[k]);
  puts("");
}

eErrorCode insertElemAt(pList l, int32_t pos, Element e) {
  eErrorCode returnCode = E_NO_ERROR;
  int32_t k = 0;
  int32_t n = 0;

  if (l != NULL)
  {
    if(!isListFull(*l)) {
      n = l->numElem;
      if(pos==-1)
        pos = n;
      for (k = n - 1; k >= pos; k--)
      {
        l->e[k + 1] = l->e[k];
      }
      l->e[pos] = e;
      l->numElem++;
    }
    else {
      returnCode = E_LIST_FULL;
    }
  }
  else {
    returnCode = E_BAD_LIST;
  }
  return returnCode;
}
 











































#if 0
eErrorCode initList(pList l) {
  eErrorCode returnCode = E_NO_ERROR;

  if(l!=NULL) {
    l->numElem=0;
  }
  else {
    returnCode = E_BAD_LIST;
  }
  return returnCode;
}

int32_t getNumElem(pList l){
  
  int32_t n = -1;

  if(l!=NULL) {
    n = l->numElem;
  }
  else {
    displayError(E_BAD_LIST);
  }
  return n;
}

bool isListEmpty(pList l) {
  bool isEmpty = false;

  if(l!=NULL) {
    isEmpty = l->numElem == 0;
  }
  else {
    displayError(E_BAD_LIST);
  }
  return isEmpty;
}

bool isListFull(pList l) {
  bool isFull = false;

  if(l!=NULL) {
    isFull = l->numElem == LIST_CAPACITY;
  }
  else {
    displayError(E_BAD_LIST);
  }
  return isFull;
}


Element getElemAt(pList l, int32_t pos){

  Element e;

  if(l!=NULL) {
    if(pos>=0 && pos<getNumElem(l))
    e = l->e[pos];
  }
  else {
    displayError(E_BAD_LIST);
  }

  return e;
}

eErrorCode insertElemAt(pList l, int32_t pos, Element e) {
  eErrorCode returnCode = E_NO_ERROR;

  if(l!=NULL) {
    if(!isListFull(l)) {

    }
    else {
      returnCode = E_LIST_FULL;
    }
  }
  else {
    returnCode = E_BAD_LIST;
  }
  return returnCode;
}
 
#endif