/**
 * \brief	Project INFO2
 * \file	wav.h
 * \author	Pierre BRESSY
 * \version	1.0
 * \date	29.12.11, 15:14
 * \bug		None.
 * \details	wav file library header file.
 */

#pragma once

#include <stdio.h>
#include <stdint.h>
#include <assert.h> 

#pragma pack(1)

/**
 * \enum eWavSampleSize
 * \brief  enumeration of various samples sizes
 */
typedef enum {
	
	E_8B_SAMPLE=8,			/*!< sample is coded as a 8 bit integer */
	E_16B_SAMPLE=16,		/*!< sample is coded as a 16 bit integer */
	
} eWavSampleSize;

/**
 * \enum eWavChannels
 * \brief  enumeration of various channels number
 */
typedef enum {
	
	E_MONO=1,			/*!<  one channel */
	E_STEREO=2,			/*!<  two channels */
	
} eWavChannels;

/**
 * \struct sRiffHeader
 * \brief Riff header definition for wav file header
 */
typedef struct
{
	uint8_t riff[4]; // must contain "RIFF"
	uint32_t length;  // must contain total length of file - 8
	uint8_t wav[4];  // must contain "WAVE"
} sRiffHeader;

/**
 * \struct sFormatHeader
 * \brief format header definition for wav file header
 */
typedef struct
{
	uint8_t fmt[4]; // must contain "fmt "
	uint32_t length; // must contain 0x10
	uint16_t audioFormat; // must contain 1 for PCM
	uint16_t numChannels; // 1 = mono, 2 = stereo, ...
	uint32_t samplingRate; // in Hz
	uint32_t byteRate; // == sample_rate * channel_number * BitsPerSample/8
	uint16_t bytesPerSample; // 1=8 bit Mono, 2=8 bit Stereo or 16 bit Mono, 4=16 bit Stereo
	uint16_t bitPerSample; // = 8, 16
} sFormatHeader;

/**
 * \struct sDataHeader
 * \brief data header definition for wav file header
 */
typedef struct
{
	uint8_t data[4] ; // must contain data
	uint32_t length; // length of data;
} sDataHeader;

/**
 * \struct sWavHeader
 * \brief full wav header definition for wav file
 */
typedef struct
{
	sRiffHeader riff;
	sFormatHeader format;
	sDataHeader data;
} sWavHeader;

#pragma pack(0)






/**
 * \fn void prepareRiffHeader(RIFF_HEADER * _riff, const uint32_t _dataLength)
 * \brief     function to prepare the riff part in the wav file header
 * \param[out]  _riff is the address of the riff header
 * \param[in]  _dataLength is the length of the data part in the wav file
 * \callgraph
 */
void prepareRiffHeader(sRiffHeader * _riff, const uint32_t _dataLength);
/**
 * \fn void prepareFormatHeader(FORMAT_HEADER * _format, const eWavChannels _numChannels, const uint32_t _samplingRate, const eWavSampleSize _bitPerSample)
 * \brief     function to prepare the format part in the wav file header
 * \param[out]  _format is the address of the format header
 * \param[in]  _numChannels is the number of channels in the wav file
 * \param[in]  _samplingRate is the sampling rate in the wav file
 * \param[in]  _bitPerSample is the number of bits per sample in the wav file
 * \callgraph
 */
void prepareFormatHeader(sFormatHeader * _format, const eWavChannels _numChannels, const uint32_t _samplingRate, const eWavSampleSize _bitPerSample);
/**
 * \fn void prepareDataHeader(DATA_HEADER * _data, const uint32_t _dataLength);
 * \brief     function to prepare the data part in the wav file header
 * \param[out]  _data is the address of the data header
 * \param[in]  _dataLength is the length of the data part in the wav file
 * \callgraph
 */
void prepareDataHeader(sDataHeader * _data, const uint32_t _dataLength);
/**
 * \fn void wavPrepareHeader(WAV_HEADER * header, const eWavChannels _numChannels, const uint32_t _samplingRate, const uint32_t _numSamples, const eWavSampleSize _bitPerSample);
 * \brief     function to prepare the data part in the wav file header
 * \param[out]  _header is the address of the header
 * \param[in]  _numChannels is the number of channels in the wav file
 * \param[in]  _samplingRate is the sampling rate in the wav file
 * \param[in]  _numSamples is the number of samples in the wav file
 * \param[in]  _bitPerSample is the number of bits per sample in the wav file
 * \callgraph
 */
void wavPrepareHeader(sWavHeader * _header, const eWavChannels _numChannels, const uint32_t _samplingRate, const uint32_t _numSamples, const eWavSampleSize _bitPerSample);


