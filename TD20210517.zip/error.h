// error.h

#pragma once

#include <stdio.h>

typedef enum
{
    E_NO_ERROR = 0,
    E_ERROR_1,
    E_ERROR_2,
    E_ERROR_3,
} eErrorCode;

void displayError(const eErrorCode e);
