//  computation.h

#pragma once

#include <math.h>
#include "error.h"

typedef struct {
    double x;
    double y;
} sPoint2D;

eErrorCode distance(const sPoint2D p1, const sPoint2D p2, double *dist);
