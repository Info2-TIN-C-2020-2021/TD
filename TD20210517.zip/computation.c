// computation.c

#include "computation.h"

eErrorCode distance(const sPoint2D p1, const sPoint2D p2, double *dist) {

  eErrorCode returnCode = E_NO_ERROR;

  *dist = sqrt(pow(p1.x-p2.x, 2) + pow(p1.y-p2.y, 2));
  if(*dist==0) {
    returnCode = E_ERROR_3;
  }
  
  return returnCode;
}
