/**
  \file      TD20210510.c
  \brief     bitmap file
  \author    Pierre BRESSY
  \version   1.0
  \date      2021-05-10 13:15:00
  \details

**/

#include <stdio.h>  // standard library for inputs and ouputs
#include <stdlib.h>
#include <stdint.h>

#include "error.h"
#include "computation.h"

int main(int argc, char const *argv[])
{
  sPoint2D bidon = {5, 4};    // x=5  y=4
  sPoint2D p1 = {.x = 10, .y = 40};
  sPoint2D p2 = {.x = -15, .y = 37};
  eErrorCode e = E_NO_ERROR;
  double d = 0.;

  e = distance(p1, p2, &d);
  displayError(e);
  printf("d(p1,p2)=%lf\n", d);

  e = distance(p1, p1, &d);
  displayError(e);
  printf("d(p1,p1)=%lf\n", d);

  if (argc == 2)
  {
    displayError(E_NO_ERROR);
  }
  else if (argc<2) {
    displayError(E_ERROR_1);
  }
  else { 
    displayError(E_ERROR_2);
  }
  return 0;
}

