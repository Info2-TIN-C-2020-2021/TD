// list.h

#pragma once

#include <stdint.h>
#include <stdbool.h>
#include "error.h"

#define LIST_CAPACITY 10 // list size
#define END_OF_LIST (-1)

typedef double Element; // element in list

typedef struct
{
  uint32_t numElem;
  Element e[LIST_CAPACITY];
} sList, *pList;

eErrorCode initList(pList l);
bool isListEmpty(pList l);
bool isListFull(pList l);
int32_t getNumElem(pList l);
void displayList(pList l);
eErrorCode insertElemAt(pList l, int32_t pos, Element e);
int32_t searchElemByValue(pList l, Element e);
eErrorCode deleteElemAt(pList l, int32_t pos);