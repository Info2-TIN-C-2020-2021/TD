// list.c

#include "list.h"


eErrorCode initList(pList l) {
  eErrorCode returnCode = E_NO_ERROR;

  if(l!=NULL) {
    l->numElem=0;
  }
  else {
    returnCode = E_BAD_LIST;
  }
  return returnCode;
}

bool isListEmpty(pList l) {

  return l->numElem == 0;
}

bool isListFull(pList l) {

  return l->numElem == LIST_CAPACITY;
}

int32_t getNumElem(pList l){

  return l->numElem;
}


void displayList(pList l) {
  int32_t k = 0;
  for (k = 0; k < l->numElem;k++)
    printf("%6.3lf ", l->e[k]);
  puts("");
}

eErrorCode insertElemAt(pList l, int32_t pos, Element e) {
  eErrorCode returnCode = E_NO_ERROR;
  int32_t k = 0;
  int32_t n = 0;

  if (l != NULL)
  {
    if(!isListFull(l)) {
      n = l->numElem;
      if(pos==-1)
        pos = n;
      for (k = n - 1; k >= pos; k--)
      {
        l->e[k + 1] = l->e[k];
      }
      l->e[pos] = e;
      l->numElem++;
    }
    else {
      returnCode = E_LIST_FULL;
    }
  }
  else {
    returnCode = E_BAD_LIST;
  }
  return returnCode;
}
 
int32_t searchElemByValue(pList l, Element e)
{
  int32_t pos=-1;
  int32_t k = 0;
  bool finished = false;

  if (l != NULL)
  {
    finished = isListEmpty(l);

    while (!finished)
    {
      if(e==l->e[k]) {
        pos = k;
        finished = true;
      }
      k++;
      if (k>=l->numElem) {
        finished = true;
      }
    }
  }
  else {
    pos = -1;
  }
  return pos;
}



eErrorCode deleteElemAt(pList l, int32_t pos) {
  eErrorCode returnCode = E_NO_ERROR;
  int32_t k = 0;

  if (l != NULL)
  {
    if(!isListEmpty(l)) {
      for (k = pos+1; k < l->numElem;k++) {
        l->e[k-1] = l->e[k];
      }
      l->numElem--;
    }
  }
  else {
    returnCode = E_BAD_LIST;
  }
  return returnCode;
}


































