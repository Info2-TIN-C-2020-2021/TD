/**
  \file      TD20210510.c
  \brief     bitmap file
  \author    Pierre BRESSY
  \version   1.0
  \date      2021-05-10 13:15:00
  \details

**/

#include <stdio.h>  // standard library for inputs and ouputs
#include <stdlib.h>
#include <stdint.h>

#include "list.h"
#include "error.h"

int main(int argc, char const *argv[])
{
  sList l;

  int32_t pos = 0;

  initList(&l);
  insertElemAt(&l, END_OF_LIST, 3.0);
  insertElemAt(&l, END_OF_LIST, 1.0);
  insertElemAt(&l, END_OF_LIST, 4.0);
  insertElemAt(&l, END_OF_LIST, 1.0);
  insertElemAt(&l, END_OF_LIST, 5.0);
  insertElemAt(&l, END_OF_LIST, 9.0);
  insertElemAt(&l, END_OF_LIST, 2.0);
  insertElemAt(&l, END_OF_LIST, 6.0);
  displayList(&l);
  pos = searchElemByValue(&l, 4);
  printf("pos=%d\n", pos);

  deleteElemAt(&l, 2);
  displayList(&l);
  return 0;
}















