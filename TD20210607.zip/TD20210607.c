/**
  \file      TD20210510.c
  \brief     bitmap file
  \author    Pierre BRESSY
  \version   1.0
  \date      2021-05-10 13:15:00
  \details

**/

#include <stdio.h>  // standard library for inputs and ouputs
#include <stdlib.h>
#include <stdint.h>

#include "error.h"
#include "chainedList.h"

int main(int argc, char const *argv[])
{
#if 1
  sChainedList l;
  initList(&l);

  pElem elem;
  Element e = 1.4;
  elem = createElem(e);
  printf("%lf\n", elem->e);

  // freeList(&l); // TODO!




  
#else
  sElem *p1 = (sElem *)malloc(sizeof(sElem));
  sElem *p2 = (sElem *)malloc(sizeof(sElem));
  sElem *p3 = (sElem *)malloc(sizeof(sElem));

  p1->prev = NULL;
  p1->next = p2;
  p1->e = 1.0;
  p2->prev = p1;
  p2->next = p3;
  p2->e = 2.0;
  p3->prev = p2;
  p3->next = NULL;
  p3->e = 3.0;

  sChainedList l;
  l.first = p1;
  l.last = p3;
  l.numElem = 3;

  sElem *elem = NULL;

  elem = l.first;
  while(elem!=NULL) {
    printf("%lf\n", elem->e);
    elem = elem->next;
  }

  elem = l.last;
  while(elem!=NULL) {
    printf("%lf\n", elem->e);
    elem = elem->prev;
  }
#endif
      return 0;
}


