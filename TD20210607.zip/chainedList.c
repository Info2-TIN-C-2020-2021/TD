// chainedList.c

#include "chainedList.h"


eErrorCode initList(pChainedList l) {
  eErrorCode returnCode = E_NO_ERROR;

  if(l!=NULL) {
    l->first = NULL;
    l->last = NULL;
    l->numElem = 0;
  }
  else {
    returnCode = E_BAD_LIST;
  }
  return returnCode;
}

bool isListEmpty(pChainedList l) {
  return l->numElem == 0;

}
int32_t getNumElem(pChainedList l) {
  return l->numElem;
}
void displayList(pChainedList l) {

  sElem *elem = NULL;

  elem = l->first;
  while(elem!=NULL) {
    printf("%lf\n", elem->e);
    elem = elem->next;
  }

}
pElem createElem(Element e) {

  pElem elem = (pElem)malloc(sizeof(sElem));
  if(elem) {
    elem->e = e;
    elem->prev = NULL;
    elem->next = NULL;
  }
  return elem;
}
