// chainedList.c

#include "chainedList.h"


eErrorCode initList(pChainedList l) {
  eErrorCode returnCode = E_NO_ERROR;

  if(l!=NULL) {
    l->first = NULL;
    l->last = NULL;
    l->numElem = 0;
  }
  else {
    returnCode = E_BAD_LIST;
  }
  return returnCode;
}

bool isListEmpty(pChainedList l) {
  return l->numElem == 0;

}
int32_t getNumElem(pChainedList l) {
  return l->numElem;
}
void displayList(pChainedList l, eSens sens) {

  sElem *elem = NULL;

  printf("List (%s):\n", sens == E_FORWARD ? "FORWARD" : "BACKWARD");
  elem = sens == E_FORWARD ? l->first : l->last;
  while (elem != NULL)
  {
    printf("%lf\n", elem->e);
    elem = sens==E_FORWARD ? elem->next:elem->prev;
  }
}
pElem createElem(Element e) {

  pElem elem = (pElem)malloc(sizeof(sElem));
  if(elem) {
    elem->e = e;
    elem->prev = NULL;
    elem->next = NULL;
  }
  return elem;
}

bool insertElemAt(sChainedList *list, int32_t pos, sElem *x) {

  sElem *p = NULL;
  sElem *n = NULL;
  int32_t k = 0;

  if(list==NULL || x==NULL) {
    return false;
  }
  
  if(list->numElem==0) {
    x->next = NULL;
    x->prev = NULL;
    list->first = x;
    list->last = x;
    list->numElem++;
  }
  else if (pos == 0) {
    list->first->prev = x;
    x->next = list->first;
    x->prev = NULL;
    list->first = x;
    list->numElem++;
  }
  else   if(pos==END_OF_LIST || pos==list->numElem) { // insert at last position
    x->next = NULL;
    x->prev = list->last;
    list->last->next = x;
    list->last = x;
    list->numElem++;
  }
  else {
    n = list->first;
    for (k = 0; k < pos;k++) {
      n = n->next;
      p = n->prev;
    }
    x->next = n;
    x->prev = p;
    n->prev = x;
    p->next = x;
    list->numElem++;
   }

  return true;
}


pElem removeElemAt(sChainedList *list, int32_t pos) {

  sElem *p = NULL;
  sElem *n = NULL;
  int32_t k = 0;

  pElem e =  NULL;

  if(list==NULL) { // bad list
    return NULL;
  }
  
  if(list->numElem==0) {// no element in list
    return NULL;
  }
  else if (pos == 0) {// remove at first position
    e = list->first; // save element

    list->first=e->next;
    if(list->first)
      list->first->prev = NULL;
    list->numElem--;
  }
  else   if(pos==END_OF_LIST || pos==(list->numElem-1)) { // remove at last position
    e = list->last; // save element

    list->last=e->prev;
    if(list->last)
      list->last->next = NULL;
    list->numElem--;
  }
  else {
    e = list->first;
    for (k = 0; k < pos;k++) {
      e = e->next;
    }
    n = e->next;
    p = e ->prev;
    n->prev = p;
    p->next = n;
    list->numElem--;
   }

  return e;
}








#if 0

bool insertElemAtFull(sChainedList *list, int32_t pos, sElem *x) {

  sElem *p = NULL;
  sElem *n = NULL;
  int32_t k = 0;

  if(list==NULL || x==NULL) {
    return false;
  }

  if (pos == 0)
  {                        // insert at first position
    if(list->numElem==0) { // list is empty
      x->next = NULL;
      x->prev = NULL;
      list->first = x;
      list->last = x;
    }
    else {
      list->first->prev = x;
      x->next = list->first;
      x->prev = NULL;
      list->first = x;
    }
    list->numElem++;
  }
  else   if(pos==END_OF_LIST || pos==list->numElem) { // insert at last position
    if(list->numElem==0) { // list is empty
      x->next = NULL;
      x->prev = NULL;
      list->first = x;
      list->last = x;
    }
    else {
      x->next = NULL;
      x->prev = list->last;
      list->last->next = x;
      list->last = x;
    }
    list->numElem++;
  }
  else {
    n = list->first;
    for (k = 0; k < pos;k++) {
      n = n->next;
      p = n->prev;
    }
    x->next = n;
    x->prev = p;
    n->prev = x;
    p->next = x;
    list->numElem++;
   }

  return true;
}

#endif 

