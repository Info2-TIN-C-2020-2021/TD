// error.h

#pragma once

#include <stdio.h>

typedef enum
{
    E_NO_ERROR = 0,
    E_BAD_LIST,
    E_LIST_FULL,
    E_ERROR_ALLOC,
} eErrorCode;

void displayError(const eErrorCode e);
