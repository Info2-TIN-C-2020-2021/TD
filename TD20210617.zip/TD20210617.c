/**
  \file      TD20210510.c
  \brief     bitmap file
  \author    Pierre BRESSY
  \version   1.0
  \date      2021-05-10 13:15:00
  \details

**/

#include <stdio.h>  // standard library for inputs and ouputs
#include <stdlib.h>
#include <stdint.h>

#include "error.h"
#include "chainedList.h"

int main(int argc, char const *argv[])
{
  sChainedList l;
  initList(&l);

  pElem elem;

  elem = createElem(2.0);
  insertElemAt(&l, 0, elem);
  elem = createElem(1.0);
  insertElemAt(&l, 0, elem);
  elem = createElem(4.0);
  insertElemAt(&l, -1, elem);
  elem = createElem(5.0);
  insertElemAt(&l, 3, elem);
  elem = createElem(3.0);
  insertElemAt(&l, 2, elem);
  displayList(&l,E_FORWARD);
  displayList(&l,E_BACKWARD);

  puts("----");
  elem = removeElemAt(&l, 0);
  displayList(&l,E_FORWARD);
  elem = removeElemAt(&l, -1);
  displayList(&l,E_FORWARD);
  elem = removeElemAt(&l, 1);
  displayList(&l,E_FORWARD);

  return 0;
}


