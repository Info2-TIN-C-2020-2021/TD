// chainedList.h

#pragma once

#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>
#include "error.h"

#define END_OF_LIST (-1)

typedef enum
{
  E_FORWARD,
  E_BACKWARD
} eSens;

typedef double Element; // element in chained list

typedef struct sElem {
  struct sElem *prev;
  struct sElem *next;
  Element e;

} sElem, *pElem;

typedef struct {
    sElem *first;
    sElem *last;
    uint32_t numElem;

} sChainedList, *pChainedList;

eErrorCode initList(pChainedList l);
bool isListEmpty(pChainedList l);
int32_t getNumElem(pChainedList l);
void displayList(pChainedList l, eSens sens);
pElem createElem(Element e);
bool insertElemAt(sChainedList *list, int32_t pos, sElem *x);
pElem removeElemAt(sChainedList *list, int32_t pos);