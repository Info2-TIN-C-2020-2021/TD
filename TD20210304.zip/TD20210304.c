/**
  \file      TD20210304.c
  \brief     create txt file
  \author    Pierre BRESSY
  \version   1.0
  \date      2021-01-11 13:55:00
  \details

**/

#include <stdio.h>  // standard library for inputs and ouputs
#include <math.h>
int main(int argc, const char *argv[]) {

  const char *filename = "data.txt";
  const char *mode = "w";

  const double pi = 3.141592654;
  const double angle_min = 0.;
  const double angle_max = 359.;
  const double step_angle = 1.;

  double angle = 0.;
  double s = 0.;

  FILE *fp = NULL;

  // double r=1/3;    !!!r=0
  // double r=1./3.;    !!!r=.3333

  fp = fopen(filename, mode);
  if(NULL==fp){
    printf("Error while opening %s\n", filename);
  }
  else {
    for (angle = angle_min; angle <= angle_max;angle+=step_angle) {
      s = sin(angle * pi / 180.);
      fprintf(fp, "%.0lf  %+6.3lf\n", angle, s);
    }

    if (0 != fclose(fp))
    {
      printf("Error while closing %s\n", filename);
    }
    else
    {
      printf("File %s created.\n", filename);
    }
  }

  return 0;
}
