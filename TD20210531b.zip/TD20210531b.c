/**
  \file      TD20210510.c
  \brief     bitmap file
  \author    Pierre BRESSY
  \version   1.0
  \date      2021-05-10 13:15:00
  \details

**/

#include <stdio.h>  // standard library for inputs and ouputs
#include <stdlib.h>
#include <stdint.h>

#include "list.h"
#include "error.h"

int main(int argc, char const *argv[])
{
  sList l;

  initList(&l);
  insertElemAt(&l, END_OF_LIST, 1.0);
  insertElemAt(&l, END_OF_LIST, 2.0);
  insertElemAt(&l, END_OF_LIST, 3.0);
  insertElemAt(&l, END_OF_LIST, 4.0);
  insertElemAt(&l, END_OF_LIST, 5.0);
  insertElemAt(&l, END_OF_LIST, 6.0);
  insertElemAt(&l, END_OF_LIST, 7.0);
  insertElemAt(&l, END_OF_LIST, 8.0);
  insertElemAt(&l, END_OF_LIST, 9.0);
  insertElemAt(&l, END_OF_LIST, 10.0);
  insertElemAt(&l, END_OF_LIST, 11.0);
  insertElemAt(&l, END_OF_LIST, 12.0);
  displayList(&l);
  freeList(&l);
  return 0;
}















