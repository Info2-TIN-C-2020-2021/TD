// fifo.c

#include "fifo.h"


eErrorCode put(pList l, Element e) {

  eErrorCode returnCode = E_NO_ERROR;

  if(l!=NULL) {
      insertElemAt(l, END_OF_LIST, e);
  }
  else {
    returnCode = E_BAD_LIST;
  }
  return returnCode;
}

Element get(pList l) {
    Element e;
    if (l != NULL)
    {
        e = l->e[0];
        deleteElemAt(l, 0);
    }
  else {
      printf("Error bad list.\n");
  }
  return e;
}
