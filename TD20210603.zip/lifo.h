// lifo.h

#pragma once

#include "list.h"
#include "error.h"

eErrorCode push(pList l, Element e);
Element pop(pList l);
